<!-- [INFO] Type: Paintball Live Page - Details: Explore the Paintball Live. [INFO]-->

<ul class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php" class="text-info"><span class="fa fa-home"></span> Home</a></li>
    <li class="breadcrumb-item"><a href="page.php?title=inflatables&extra=none" class="text-info">All Inflatables</a></li>
    <li class="breadcrumb-item"><a href="page.php?title=inflatables&extra=none#competition" class="text-info">Competition Games</a></li>
    <li class="breadcrumb-item">Paintball Live</li>
</ul>

<div>
    <h3>Paintball Live</h3>
    <p>With one of the only enclosed mobile Paintball Arenas you'll find on the East Coast, we bring safe and exciting Paintball games to you!</p>
</div>

<div class="container">
    <div class="row mb-3">
        <div class="col-lg-12 p-0" id="gallery">
            <!--Equipment image thumbnail-->
            <!-- <img src="images/Ninja Warrior/NinjaWarrior01.jpg" class="img-fluid img-thumbnail"/> -->
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-lg-12 p-0">
            <div class="d-flex flex-nowrap justify-content-center mt-1">
                <!-- Equipment images
                <div class="unit_card shadow-sm m-2"><a href="#gallery"><img src="images/Ninja Warrior/NinjaWarrior01.jpg" class="card-img-top img-fluid img-thumbnail" style="height: 134px"/></a></div>
                <div class="unit_card shadow-sm m-2"><a href="#gallery"><img src="images/Ninja Warrior/NinjaWarrior02.jpg" class="card-img-top img-fluid img-thumbnail" style="height: 134px"/></a></div>
                <div class="unit_card shadow-sm m-2"><a href="#gallery"><img src="images/Ninja Warrior/NinjaWarriorWall01.jpg" class="card-img-top img-fluid img-thumbnail" /></a></div>
                -->
            </div>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-lg-7 col-md-12 p-0">
            <!-- UNIT DESCRIPTION CARD -->
            <div class="card shadow-sm m-1">
                <div class="card-header p-2"><h5>Unit Description</h5></div>
                <div class="card-body p-2">
                    <p>Games are played quickly and similarly to Speed Ball allowing many different people to participate in a 4 hour period.
                    We play 2 on 2 or 3 on 3 and limit the ball count to make sure the games more quickly so more people get to play. Arena, 
                    paintball markers(guns), air tanks, paintballs, protective wear (masks, gloves, jerseys, and pants), referees, and bunkers are all provided.
                    At this time, this service is only available for use outdoors. All participants are required to sign a liability waiver.</p>

                    <p>If weather does not permit us to operate outside, now we can move inside with or without the arena and use all the great bunkers with 
                    our <a href='page.php?title=airbunkerball&extra=none'>Air Bunker Ball</a> system. It works the same as paintball except you shoot foam balls. 
                    We still use the same jerseys, markers, masks, etc. Air Bunker Ball is also available instead of paintball at any time.</p>
                </div>
            </div>
        </div>
        <div class="col-lg-5 col-md-12 p-0">
            <!-- UNIT INFO LIST -->
            <div class="card shadow-sm m-1">
                <div class="card-header p-2"><h5>Unit Specifications</h5></div>
                <div class="card-body p-2">
                    <div class="list-group list-group-flush">
                        <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" 
                        data-toggle="tooltip" 
                        title="Actual Dimensions of the Unit">
                            <span><i class="fal fa-ruler-triangle text-info"></i> Dimensions</span> 80'L x 40'W x 22'H </a>
                        <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" 
                        data-toggle="tooltip" 
                        title="Recommended Total Space Needed for Setup">
                            <span><i class="fal fa-shoe-prints text-info"></i> Footprint</span> 100'L x 65'W x 22'H </a>
                        <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" 
                        data-toggle="tooltip" 
                        title="Individual 110v - 20amp Breaker">
                            <span><i class="fal fa-plug text-info"></i> Power</span>4 AC Circuits</a>
                        <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" 
                        data-toggle="tooltip" 
                        title="Max Users Participating at Once">
                            <span><i class="fal fa-users text-info"></i> Max Participants</span> 6 </a>
                        <a class="list-group-item list-group-item-action d-flex justify-content-between align-items-center" 
                        data-toggle="tooltip" 
                        title="Additional Limitations to Operate the Unit Safely">
                            <span><i class="fal fa-exclamation-circle text-warning"></i> Limitations</span>Min. player age: 10yrs+</a>
                    </div>
                </div>
            </div>
        </div>
    </div>    
</div>
