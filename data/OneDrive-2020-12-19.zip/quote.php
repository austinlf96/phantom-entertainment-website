<!-- [INFO] Type: Quote Page - Details: Basic Phantom Entertainment Quote Page [INFO]-->

<iframe src='https://www.inflatableoffice.com/quotes/quoteme.php?name=Phantom+Entertainment' title='quote_page' height='1000' class='w-100'></iframe>